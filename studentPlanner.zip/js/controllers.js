angular.module('app.controllers', [])
  
.controller('signupCtrl', function($scope) {

})
   
.controller('loginCtrl', function($scope) {

})
 